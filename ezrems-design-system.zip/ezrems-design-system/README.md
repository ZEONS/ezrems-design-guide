# ezREMS Design System

## 파일 구조
```
ezrems-design-system/
├── index.html          ← 메인 템플릿 (임대계약관리 데모)
├── css/
│   ├── variables.css   ← CSS 변수 (색상, 타이포, 간격)
│   ├── base.css        ← 리셋 + 기본 요소 스타일
│   ├── layout.css      ← GNB, 탭바, 스플릿 레이아웃
│   └── components.css  ← 버튼, 배지, 폼, 테이블 컴포넌트
└── js/
    ├── common.js       ← 공통 유틸리티 (날짜, 숫자, DOM, Ajax, Toast)
    └── page.js         ← 페이지별 비즈니스 로직 (샘플 데이터 포함)
```

## 실행 방법
index.html 파일을 브라우저에서 열거나,
VS Code의 Live Server 확장을 사용하세요.

## 색상 팔레트
| 이름 | HEX | 용도 |
|------|-----|------|
| primary-dark  | #252E34 | 헤더 배지, 만료 날짜 |
| primary-blue  | #3B70DA | 서브 배지, 링크 |
| primary-navy  | #0A2F49 | 버튼, 삭제 |
| accent        | #EEA11A | 조회 버튼 |
| danger        | #FF0000 | 필수 항목 |

## 버튼 사용법
```html
<button class="btn primary">조회</button>
<button class="btn outline">등록</button>
<button class="btn contained">삭제</button>
<button class="btn secondary">저장</button>
<button class="btn outline--danger">전자계약서 발송</button>
```

## 새 페이지 만들기
1. index.html 복사 후 페이지명 변경
2. js/page.js 복사 후 페이지 로직 작성
3. css/variables.css의 변수 활용
