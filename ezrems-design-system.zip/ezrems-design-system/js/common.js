/* =============================================
   ezREMS Common Utilities (common.js)
   ============================================= */
'use strict';

const EzREMS = (() => {

  /* ── 날짜 유틸 ── */
  const Date_ = {
    format(date) {
      const d = date instanceof Date ? date : new Date(date);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return isNaN(d) ? '' : `${y}-${m}-${day}`;
    },
    today() { return this.format(new Date()); },
    diffDays(dateStr) {
      const now = new Date(); now.setHours(0,0,0,0);
      const target = new Date(dateStr);
      return Math.ceil((target - now) / 86400000);
    },
    isExpired(dateStr) { return this.diffDays(dateStr) < 0; },
    isNear(dateStr, days = 30) {
      const d = this.diffDays(dateStr);
      return d >= 0 && d <= days;
    },
    /* 날짜 배지 클래스 결정 */
    badgeClass(dateStr) {
      if (!dateStr) return '';
      if (this.isExpired(dateStr)) return 'date-badge--expired';
      if (this.isNear(dateStr, 90)) return 'date-badge--near';
      return 'date-badge--future';
    },
  };

  /* ── 숫자 포맷 ── */
  const Num = {
    comma(val) {
      const n = parseInt(String(val).replace(/,/g, ''), 10);
      return isNaN(n) ? '' : n.toLocaleString('ko-KR');
    },
    unComma(val) { return parseInt(String(val).replace(/,/g, ''), 10) || 0; },
    /** 금액 입력 필드 자동 콤마 */
    bindCommaInput(selector) {
      document.querySelectorAll(selector).forEach(el => {
        el.addEventListener('input', function () {
          const pos = this.selectionStart;
          const raw = this.value.replace(/[^0-9]/g, '');
          this.value = raw ? parseInt(raw).toLocaleString('ko-KR') : '';
        });
      });
    },
  };

  /* ── DOM 유틸 ── */
  const Dom = {
    /** id 또는 selector로 요소 가져오기 */
    get(selector) { return document.querySelector(selector); },
    getAll(selector) { return document.querySelectorAll(selector); },
    /** 요소 표시/숨기기 */
    show(selector) { const el = typeof selector === 'string' ? this.get(selector) : selector; if (el) el.style.display = ''; },
    hide(selector) { const el = typeof selector === 'string' ? this.get(selector) : selector; if (el) el.style.display = 'none'; },
    /** 폼 초기화 */
    resetForm(formSelector) {
      this.getAll(`${formSelector} input, ${formSelector} select, ${formSelector} textarea`)
        .forEach(el => { el.type === 'checkbox' ? el.checked = false : el.value = ''; });
    },
    /** 값 채우기 */
    fillForm(formSelector, data) {
      Object.keys(data).forEach(key => {
        const el = this.get(`${formSelector} [name="${key}"], ${formSelector} #${key}`);
        if (!el) return;
        if (el.type === 'checkbox') el.checked = !!data[key];
        else el.value = data[key] ?? '';
      });
    },
  };

  /* ── 알림 ── */
  const Toast = {
    show(message, type = 'info', duration = 3000) {
      const el = document.createElement('div');
      el.className = `toast toast--${type}`;
      el.textContent = message;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), duration);
    },
    success(msg) { this.show(msg, 'success'); },
    error(msg)   { this.show(msg, 'error'); },
    info(msg)    { this.show(msg, 'info'); },
  };

  /* ── 로딩 ── */
  const Loading = {
    _el: null,
    show() {
      if (this._el) return;
      this._el = document.createElement('div');
      this._el.className = 'loading-overlay';
      this._el.innerHTML = '<div class="loading-spinner"></div>';
      document.body.appendChild(this._el);
    },
    hide() {
      if (this._el) { this._el.remove(); this._el = null; }
    },
  };

  /* ── AJAX (fetch 래퍼) ── */
  const Ajax = {
    async get(url, params = {}) {
      const query = new URLSearchParams(params).toString();
      const res = await fetch(query ? `${url}?${query}` : url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    },
    async post(url, data = {}) {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    },
  };

  /* ── 테이블 렌더링 ── */
  const Table = {
    /**
     * 데이터 테이블 행 렌더링
     * @param {string} tbodySelector - tbody 셀렉터
     * @param {Array}  data          - 배열 데이터
     * @param {Function} rowFn       - (row, idx) => '<tr>...</tr>' 반환 함수
     */
    render(tbodySelector, data, rowFn) {
      const tbody = document.querySelector(tbodySelector);
      if (!tbody) return;
      tbody.innerHTML = data.length
        ? data.map((row, i) => rowFn(row, i)).join('')
        : '<tr><td colspan="100" style="text-align:center;padding:20px;color:#999;">데이터가 없습니다.</td></tr>';
    },
    /** 날짜 셀 렌더링 (만료 여부에 따라 배지 자동 적용) */
    dateCell(dateStr) {
      if (!dateStr) return '<td></td>';
      const cls = Date_.badgeClass(dateStr);
      return cls
        ? `<td><span class="date-badge ${cls}">${dateStr}</span></td>`
        : `<td>${dateStr}</td>`;
    },
  };

  /* ── GNB 타이머 ── */
  const Timer = {
    _interval: null,
    _seconds: 1800,
    start(seconds = 1800) {
      this._seconds = seconds;
      const el = document.querySelector('.gnb__timer');
      if (!el) return;
      this._interval = setInterval(() => {
        if (this._seconds <= 0) { clearInterval(this._interval); return; }
        this._seconds--;
        const m = String(Math.floor(this._seconds / 60)).padStart(2, '0');
        const s = String(this._seconds % 60).padStart(2, '0');
        el.textContent = `${m}:${s}`;
      }, 1000);
    },
    reset(seconds = 1800) {
      clearInterval(this._interval);
      this.start(seconds);
    },
  };

  /* ── 탭 관리 ── */
  const Tabs = {
    init() {
      document.querySelectorAll('.tab-bar__item').forEach(tab => {
        tab.addEventListener('click', () => {
          document.querySelectorAll('.tab-bar__item').forEach(t => t.classList.remove('tab-bar__item--active'));
          tab.classList.add('tab-bar__item--active');
        });
        const closeBtn = tab.querySelector('.tab-close');
        if (closeBtn) {
          closeBtn.addEventListener('click', e => {
            e.stopPropagation();
            tab.remove();
          });
        }
      });
    },
  };

  /* ── 공개 API ── */
  return { Date_, Num, Dom, Toast, Loading, Ajax, Table, Timer, Tabs };

})();

/* DOM 준비 후 공통 초기화 */
document.addEventListener('DOMContentLoaded', () => {
  EzREMS.Tabs.init();
  EzREMS.Timer.start(1800);
  EzREMS.Num.bindCommaInput('.form-control--amount');
});