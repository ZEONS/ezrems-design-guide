/* =============================================
   ezREMS Page Business Logic (page.js)
   페이지별 로직을 여기에 작성합니다.
   ============================================= */
'use strict';

/* ── 샘플 데이터 ── */
const SAMPLE_DATA = [
  { no: 1,  dong: '',    reg: '',    use: '',     type: '',    name: 'a',      start: '2023-04-10', end: '2027-04-09', move: '',           out: '' },
  { no: 2,  dong: '',    reg: '',    use: '',     type: '',    name: 'a',      start: '2023-04-10', end: '2027-04-09', move: '',           out: '' },
  { no: 3,  dong: '',    reg: '',    use: '',     type: '',    name: '베우성', start: '2023-03-10', end: '2024-03-09', move: '',           out: '' },
  { no: 4,  dong: '',    reg: '',    use: '',     type: '',    name: '박찬호', start: '2026-04-20', end: '2028-04-19', move: '',           out: '' },
  { no: 5,  dong: '',    reg: '',    use: '',     type: '',    name: '이승연', start: '2025-08-25', end: '2026-08-24', move: '',           out: '' },
  { no: 6,  dong: '',    reg: '',    use: '',     type: '',    name: '박찬호', start: '2025-08-28', end: '2026-08-27', move: '',           out: '' },
  { no: 7,  dong: '',    reg: '',    use: '',     type: '',    name: '김재옥', start: '2025-12-24', end: '2027-12-23', move: '',           out: '' },
  { no: 8,  dong: '쥬라기', reg: '101', use: '101', type: '',  name: '김황후', start: '2024-04-02', end: '2025-04-01', move: '',          out: '' },
  { no: 9,  dong: '쥬라기', reg: '101', use: '101', type: '',  name: '김황후', start: '2024-04-02', end: '2028-04-01', move: '',          out: '' },
  { no: 10, dong: '쥬라기', reg: '101', use: '101-1', type: '84A', name: '구원스', start: '2024-06-25', end: '2025-06-24', move: '',     out: '' },
  { no: 11, dong: '쥬라기', reg: '101', use: '101-2', type: '84A', name: '김재옥', start: '2022-07-25', end: '2024-07-24', move: '',     out: '' },
  { no: 12, dong: '101', reg: '1004', use: '1004', type: '',  name: '이규인', start: '2025-11-06', end: '2026-12-31', move: '2023-11-06', out: '' },
  { no: 13, dong: '101', reg: '1004', use: '1004', type: '',  name: '이규인', start: '2025-11-06', end: '2026-12-31', move: '2023-11-06', out: '' },
  { no: 14, dong: '102', reg: '1004', use: '1004', type: '',  name: '구원스', start: '2023-12-27', end: '2031-12-26', move: '',          out: '' },
  { no: 15, dong: '102', reg: '1004', use: '1004', type: '',  name: '구원스', start: '2031-12-27', end: '2032-12-26', move: '',          out: '' },
  { no: 16, dong: '102', reg: '1004', use: '1004', type: '',  name: '구원스', start: '2032-12-27', end: '2034-12-26', move: '',          out: '' },
  { no: 17, dong: '109', reg: '999',  use: '999',  type: '74B-1', name: '구원스', start: '2025-01-16', end: '2027-01-15', move: '',     out: '' },
];

const DETAIL_DATA = {
  name: 'a',
  bizNo: '880817-6******',
  contact: '',
  taxManager: 'ㄴooㄴooㄴo',
  phone: '',
  email: '1',
  channel: '직접계약(법인)',
  subscType: '삼성동 뉴스테이+ 특약 4년',
  deposit: '',
  contractType: '단독관리비',
  contractDate: '2022-12-16',
  contractPeriodStart: '2023-04-10',
  contractPeriodEnd: '2027-04-09',
  moveInDoc: '2023-04-10',
  moveIn: '',
  vacateExpected: '2025-12-17',
  vacateDate: '',
  rent: '0',
  rentBaseDate: '2023-04-10',
  rentTaxable: '과세',
  rentPayType: '월선납',
  rentPayDay: '15',
  management: '0',
  mgmtBaseDate: '2023-04-10',
  mgmtTaxable: '면세',
  mgmtPayType: '중간납',
  mgmtPayDay: '15',
  depositSum: '',
  depositChange: '-',
  rentChange: '-',
  mgmtChange: '-',
  insuranceCheck: false,
  rentSignalDate: '2025-11-20',
};

/* ── 현재 선택 행 ── */
let selectedRow = null;

/* ── 테이블 행 생성 함수 ── */
function renderRow(row, idx) {
  const endBadge = (() => {
    if (!row.end) return '';
    const cls = EzREMS.Date_.badgeClass(row.end);
    return cls ? `<span class="date-badge ${cls}">${row.end}</span>` : row.end;
  })();

  const dong = row.dong ? `<span class="tag-badge">${row.dong}</span>` : '';
  const reg  = row.reg  ? `<span class="tag-badge">${row.reg}</span>`  : '';
  const use  = row.use  ? `<span class="tag-badge">${row.use}</span>`  : '';

  return `<tr data-idx="${idx}" class="${idx === 0 ? 'row--selected' : ''}">
    <td>${row.no}</td>
    <td>${dong}</td>
    <td>${reg}</td>
    <td>${use}</td>
    <td>${row.type}</td>
    <td style="text-align:left;padding-left:8px">${row.name}</td>
    <td>${row.start}</td>
    <td>${endBadge}</td>
    <td>${row.move || ''}</td>
    <td>${row.out || ''}</td>
  </tr>`;
}

/* ── 상세 폼 채우기 ── */
function fillDetail(data) {
  EzREMS.Dom.fillForm('#detailForm', data);
  document.getElementById('insuranceCheck').checked = data.insuranceCheck;
}

/* ── 행 클릭 이벤트 ── */
function bindRowClick() {
  document.querySelector('#contractTbody').addEventListener('click', e => {
    const tr = e.target.closest('tr');
    if (!tr) return;
    document.querySelectorAll('#contractTbody tr').forEach(r => r.classList.remove('row--selected'));
    tr.classList.add('row--selected');
    selectedRow = tr;
    fillDetail(DETAIL_DATA);
    EzREMS.Toast.info('행을 선택했습니다.');
  });
}

/* ── 조회 버튼 ── */
function bindSearchBtn() {
  document.getElementById('searchBtn').addEventListener('click', () => {
    EzREMS.Loading.show();
    setTimeout(() => {
      EzREMS.Table.render('#contractTbody', SAMPLE_DATA, renderRow);
      bindRowClick();
      EzREMS.Loading.hide();
      EzREMS.Toast.success('조회가 완료되었습니다. (' + SAMPLE_DATA.length + '건)');
    }, 600);
  });
}

/* ── 저장 버튼 ── */
function bindSaveBtn() {
  document.getElementById('saveBtn').addEventListener('click', () => {
    EzREMS.Toast.success('저장되었습니다.');
  });
}

/* ── 엑셀 버튼 (테이블 → CSV 변환) ── */
function bindExcelBtn() {
  document.getElementById('excelBtn').addEventListener('click', () => {
    const rows = [['No', '동', '등기호실', '사용호실', '타입', '계약자명', '계약시작일', '계약종료일', '실입주일', '퇴거']];
    SAMPLE_DATA.forEach(r => rows.push([r.no, r.dong, r.reg, r.use, r.type, r.name, r.start, r.end, r.move, r.out]));
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = '임대계약관리.csv';
    a.click(); URL.revokeObjectURL(url);
    EzREMS.Toast.success('엑셀(CSV)로 다운로드 되었습니다.');
  });
}

/* ── 삭제 버튼 ── */
function bindDeleteBtn() {
  document.getElementById('deleteBtn').addEventListener('click', () => {
    if (!confirm('선택한 항목을 삭제하시겠습니까?')) return;
    EzREMS.Toast.error('삭제되었습니다.');
  });
}

/* ── 아래로 이동 버튼 ── */
function bindScrollBtn() {
  document.getElementById('scrollDownBtn').addEventListener('click', () => {
    document.querySelector('.split-view__detail').scrollTo({ top: 9999, behavior: 'smooth' });
  });
}

/* ── 페이지 초기화 ── */
document.addEventListener('DOMContentLoaded', () => {
  /* 초기 테이블 렌더링 */
  EzREMS.Table.render('#contractTbody', SAMPLE_DATA, renderRow);
  /* 초기 상세 폼 채우기 */
  fillDetail(DETAIL_DATA);
  /* 이벤트 바인딩 */
  bindRowClick();
  bindSearchBtn();
  bindSaveBtn();
  bindExcelBtn();
  bindDeleteBtn();
  bindScrollBtn();
});